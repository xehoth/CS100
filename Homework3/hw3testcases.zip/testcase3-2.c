#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int main()
{
    Node testType;
    assert(sizeof(typeof(testType.data)) == 4);
    testType.data = new_student("Please check your Node Structure", 0);
    testType.data = new_student("Please check your Node Structure", 0);
    testType.data = new_student("Please check your Node Structure", 0);
    int tcase = 0;
    //scanf("%d", &tcase);
    for(tcase = 1; tcase <= 10; tcase++){
        LinkedList* ll = (LinkedList*)malloc(sizeof(LinkedList));
        list_init(ll);
        switch(tcase){
            case 1:
            {
            /* test for list_init */
                assert(ll->size == 0 && ll->head == NULL && ll->tail == NULL);
                break;
            }
            case 2:
            {
            /* test for single node insert */
                Student* stu = new_student("betading", 100);
                list_insert(ll, stu);
                assert(ll->head->data == stu && ll->tail->data == stu && ll->size == 1);
                break;
            }
            case 3:
            {
            /* test for multiple nodes insert */
                Student* stu1 = new_student("betading", 100);
                Student* stu2 = new_student("foobar", 99);
                list_insert(ll, stu1);
                list_insert(ll, stu2);
                assert(ll->head->data == stu1 && ll->tail->data == stu2 && ll->size == 2);
                break;
            }        
            case 4:
            {
            /* 10 nodes insrtation */
                Student* A[10];
                for (int i = 0; i < 10; i++)
                {
                    char s[4] = "AAA";
                    s[2] += i;
                    A[i] = new_student(s, 100-i);
                    list_insert(ll, A[i]);
                }
                int flag = 1, cnt = 0;
                for (Node* iter = ll->head; iter != NULL; iter = iter->next, cnt++)
                {
                    if (cnt == 0) 
                    {
                        if (!(iter->data->score == 100.0 && strcmp(iter->data->name, "AAA") == 0))
                            flag = 0;
                    }
                    else if (cnt == 3)
                    {
                        if (!(iter->data->score == 97.0 && strcmp(iter->data->name, "AAD") == 0))
                            flag = 0;
                    }
                    else if (cnt == 9)
                    {
                        if (!(iter->data->score == 91.0 && strcmp(iter->data->name, "AAJ") == 0))
                            flag = 0;
                    }  
                }
                assert(flag && ll->size == 10 && cnt == 10);
                break;
            }
            case 5:
            {   
            /* remove inserior node */
                Student* stu1 = new_student("betading", 100);
                Student* stu2 = new_student("foobar", 99);
                Student* stu3 = new_student("GuGUgUgu", 101);
                list_insert(ll, stu1);
                list_insert(ll, stu2);
                list_insert(ll, stu3);
                Node* ret = list_remove(ll, ll->head->next);
                assert(ll->head->data == stu1 && ll->tail->data == stu3 
                    && ll->size == 2 && ll->head->next == ll->tail && ret == ll->tail);
                break;
            }
            case 6:
            {
            /* remode head(head != tail) */
                Student* stu1 = new_student("betading", 100);
                list_insert(ll, stu1);
                Student* stu2 = new_student("foobar", 99);
                list_insert(ll, stu2);
                Student* stu3 = new_student("GuGUgUgu", 101);
                list_insert(ll, stu3);
                list_remove(ll, ll->head);
                assert(ll->head->data == stu2 && ll->tail->data == stu3 
                    && ll->size == 2 && ll->head->next == ll->tail);
                break;
            }
            case 7:
            {
            /* remove tail & head(head == tail) */
                Student* stu1 = new_student("betading", 100);
                list_insert(ll, stu1);
                list_remove(ll, ll->head);
                assert(ll->head == NULL && ll->tail == NULL && ll->size == 0);
                break;
            }
            case 8:
            {
            /* remove invalid nodes */
                Student* low = new_student("low", 31);
                Student* mid = new_student("mid", 32);
                Student* high = new_student("high", 33);
                Node* high_node = (Node*)malloc(sizeof(Node));
                high_node->data = high;
                assert(low->score == 31);
                list_insert(ll, low);
                list_insert(ll, mid);
                assert(list_remove(ll, high_node) == NULL && ll->size == 2);
                break;
            }
            case 9:
            {
            /*tests for list_erase */
                Student* low = new_student("low", 31);
                Student* mid = new_student("mid", 32);
                Student* high = new_student("high", 33);
                list_insert(ll, low);
                list_insert(ll, mid);
                list_insert(ll, high);
                assert(ll->head != NULL && ll->size == 3);
                list_erase(ll);
                assert(ll->size == 0 && ll->head == NULL && ll->tail == NULL);
                break;
            }
            case 10:
            {
                Student* low = new_student("lyq", 0);
                Student* baz = new_student("baz", 1);
                list_insert(ll, low);
                list_insert(ll, baz);
                list_insert(ll, new_student("foo", 10));
                list_remove(ll, ll->head);
                list_remove(ll, ll->tail);
                assert(ll->size == 1 && ll->tail != NULL && ll->head != NULL);
                assert(strcmp(ll->head->data->name, "baz") == 0 && ll->tail->data->score == 1);
                list_erase(ll);
                assert(ll->size == 0 && ll->head == NULL);
                break;
            }
            default:
                assert(0 == 1);
                break;
        }
        
    } 
    printf("All cases passed!\n");   
}