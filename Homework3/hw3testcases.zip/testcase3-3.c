#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int main()
{

    Node testType;
    assert(sizeof(typeof(testType.data)) == 4);
    testType.data = new_student("Please check your Node Structure", 0);
    testType.data = new_student("Please check your Node Structure", 0);
    testType.data = new_student("Please check your Node Structure", 0);
    LinkedList testListType;
    testListType.head = NULL; testListType.size = 0;    
    testListType.head = NULL; testListType.size = 0;
    testListType.head = NULL; testListType.size = 0;
    Node* testReturnType = list_search_by_name(&testListType, "Please check your return types");
    testReturnType = list_search_by_name(&testListType, "Please check your return types");
    testReturnType = list_search_by_name(&testListType, "Please check your return types");
    char* testResult[128];
    int testReturnType2 = list_search_by_score(&testListType, 0.0, 0.0, testResult);
    testReturnType2 = list_search_by_score(&testListType, 0.0, 0.0, testResult);
    testReturnType2 = list_search_by_score(&testListType, 0.0, 0.0, testResult);
    
       
    int tcase = 0;
    //scanf("%d", &tcase);               
    for(int tcase = 1; tcase <= 10; tcase++){

        LinkedList* ll = (LinkedList*)malloc(sizeof(LinkedList));
        list_init(ll);
        char* names[] = {"eInWAnwbdb", "eInWAnwbd", "eInWAnwb", "eInWAnw", "eInWAn",\
                            "NXUmrQwLFv", "NXUmrQwLF", "NXUmrQwL", "NXUmrQw", "NXUmrQ",\
                            "HpaKEBEsOv", "HpaKEBEsO", "HpaKEBEs", "HpaKEBE", "HpaKEB"};
        for(int i = 0; i < 10; i++)
            list_insert(ll, new_student(names[i], 5.0*i));
        for(int i = 0; i < 5; i++)
            list_insert(ll, new_student(names[10 + i], 24.5 + i));
        list_insert(ll, new_student("foo", 100));    

        switch(tcase){
            case 1:
            case 2:
            {
            /* valid search name */
                Node* foo = list_search_by_name(ll, "NXUmrQ");
                assert(foo != NULL && strcmp(foo->data->name, "NXUmrQ") == 0 && foo->data->score == 45.0);
                break;
            }
            case 3:
            case 4:
            {
            /* invalid search name */               
                assert(list_search_by_name(ll, "foobar") == NULL);
                break;
            }
            case 5:
            case 6:
            {
            /* invalid search score */
                char* result[RES_SIZE];
                result[0] = "FooBarBaz";
                int nil = list_search_by_score(ll, 70, 80, result);
                assert(nil == 0 && strcmp(result[0], "FooBarBaz") == 0);
                break;
            }
            case 7:
            case 8:
            {
            /* valid search score: 1 result */
                char* result[RES_SIZE];
                result[1] = "FooBarBaz";
                int uno = list_search_by_score(ll, 39, 41, result);
                assert(uno == 1 && strcmp(result[0], "NXUmrQw") == 0 && strcmp(result[1], "FooBarBaz") == 0);
                break;
            }
            case 9:
            case 10:
            {
            /* valid search score and sorting*/
                char* result[RES_SIZE];
                int num = list_search_by_score(ll, 20, 30, result);
                // printf("num == %d && ", num);
                // for(int i = 0; i < num; i++){
                //     printf("strcmp(result[%d], %s) == 0 && ", i, result[i]);
                // }
                assert(num == 8 && strcmp(result[0], "HpaKEB") == 0 && strcmp(result[2], "HpaKEBEs") == 0 
                                && strcmp(result[4], "HpaKEBEsOv") == 0 && strcmp(result[5], "NXUmrQwLF") == 0 
                                && strcmp(result[6], "NXUmrQwLFv") == 0 && strcmp(result[7], "eInWAn") == 0);
                break;
            }
            default:
                assert(0 == 1);
                break;
        }

        list_erase(ll);
        free(ll);
    }
    printf("All cases passed!\n");   
}
//APPEND END
