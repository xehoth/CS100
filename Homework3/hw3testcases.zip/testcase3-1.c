#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int main()
{
    int tcase = 0;
    //scanf("%d", &tcase);
    char* test[] = {"Gugu", "GUgu", "guGu", "GuGu", "gugu"};
    for(int tcase = 1; tcase <= 10; tcase++){
        switch(tcase){
            case 1:
                string_sort(test, 2);
                assert(test[0] == "GUgu" && test[1] == "Gugu" && test[2] == "guGu");
                break;
            case 2:
                string_sort(test + 2, 2);
                assert(test[2] == "GuGu");
                break;
            case 3:
            {
                char** checkOutOfBound = & test[5];
                string_sort(test, 5);    
                assert(test[4] == "gugu" && test[2] == "Gugu");
                assert(*checkOutOfBound == test[5]);
                break;
            }        
            case 4:
            {
                char* t2[] = {"ghJyQ", "seiSP", "EVuSU", "fLpjK", "eajHe", "TXDRB", "WBDhR", "kuyAP", "rviuS", "VYIpS", "fBSLt", "lrdvm", "ysvxH", "uLVgU", "mQozb"};
                string_sort(t2, 15);
                assert(t2[1] == "TXDRB" && t2[6] == "fLpjK" && t2[11] == "rviuS" && t2[14] == "ysvxH");
                break;
            }
            case 5:
            {   
                char* t3[] = {"KfheEocoib", "KfheEocoi", "KfheEoco", "KfheEoc", "KfheEo"};
                string_sort(t3, 5);
                // for (int i = 0; i < 5; i++) 
                //     printf("t3[%d] == \"%s\" && ", i, t3[i]);
                assert(t3[0] == "KfheEo" && t3[1] == "KfheEoc" && t3[2] == "KfheEoco" && t3[3] == "KfheEocoi" && t3[4] == "KfheEocoib");
                break;
            }
            case 6:
            {
                char* t4[] = {"eInWAnwbdb", "eInWAnwbd", "eInWAnwb", "eInWAnw", "eInWAn",\
                                "NXUmrQwLFv", "NXUmrQwLF", "NXUmrQwL", "NXUmrQw", "NXUmrQ",\
                                "HpaKEBEsOv", "HpaKEBEsO", "HpaKEBEs", "HpaKEBE", "HpaKEB",\
                                "SoLSyJujQd", "SoLSyJujQ", "SoLSyJuj", "SoLSyJu", "SoLSyJ",\
                                "mbYHLoLvGi", "mbYHLoLvG", "mbYHLoLv", "mbYHLoL", "mbYHLo"};
                string_sort(t4, 25);
                // for (int i = 0; i < 25; i+=3) 
                //     printf("t4[%d] == \"%s\" && ", i, t4[i]);
                assert(t4[0] == "HpaKEB" && t4[3] == "HpaKEBEsO" && t4[6] == "NXUmrQw" && t4[9] == "NXUmrQwLFv" && t4[12] == "SoLSyJuj"\
                    && t4[15] == "eInWAn" && t4[18] == "eInWAnwbd" && t4[21] == "mbYHLoL" && t4[24] == "mbYHLoLvGi");
                break;
            }
            case 7:
            {
                char* t5[]= {"2", "1"};
                string_sort(t5, 1);
                assert(t5[0] == "2");
                break;
            }
            case 8:
            {
                Student A;
                strcpy(A.name, "Aname");
                A.score = 100;
                assert(A.score == 100 && strcmp(A.name, "Aname") == 0);
                break;
            }
            case 9:
            {
                Student* A = new_student("betading", 233);
                assert(A->score == 233 && strcmp(A->name, "betading") == 0);
                free(A);
                break;
            }
            case 10:
            {
                Student* A[10];
                for (int i = 0; i < 10; i++){
                    char s[4] = "AAA";
                    s[2] += i;
                    A[i] = new_student(s, 100-i);
                }
                assert(A[1]->score == 99.0 && strcmp(A[1]->name, "AAB") == 0
                    && A[3]->score == 97.0 && strcmp(A[3]->name, "AAD") == 0
                    && A[8]->score == 92.0 && strcmp(A[8]->name, "AAI") == 0
                    && A[9]->score == 91.0 && strcmp(A[9]->name, "AAJ") == 0);
                for (int i = 0; i < 10; i++){
                    free(A[i]);
                }
                break;
            }
            default:
                assert(0 == 1);
                break;
        }
    }
    printf("All cases passed!\n");
}