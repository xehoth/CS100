#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <iostream>
#include <math.h>

class Person {
public:
  Person();
  virtual ~Person();

  int & annualIncome();
  int & age();
  const int & annualIncome() const;
  const int & age() const;

  void print();
  bool operator<( const Person & p2 ) const;

private:
  int m_age;
  int m_annualIncome;
};

Person::Person() {}

Person::~Person() {}

int &
Person::age() {
  return m_age;
}

int &
Person::annualIncome() {
  return m_annualIncome;
}

const int &
Person::age() const {
  return m_age;
}

const int &
Person::annualIncome() const {
  return m_annualIncome;
}

void
Person::print() {
  std::cout << "New person:\n";
  std::cout << "Age: " << m_age << "\n";
  std::cout << "Income: " << m_annualIncome << "\n\n";
}

bool
Person::operator<( const Person & p2 ) const {
  if( this->age() > p2.age() )
    return true;
  if( this->age() < p2.age() )
    return false;
  if( this->annualIncome() > p2.annualIncome() )
    return true;
  return false;
}

/*
bool comparatorFunction( Person & p1, Person & p2 ) {
  if( p1.age() > p2.age() )
    return true;
  if( p1.age() < p2.age() )
    return false;
  if( p1.annualIncome() > p2.annualIncome() )
    return true;
  return false;
}
*/

/*
class Comp
{
public:
  bool operator()(
      const Person & p1,
      const Person & p2 )
  {
    if( p1.age() > p2.age() )
      return true;
    if( p1.age() < p2.age() )
      return false;
    if( p1.annualIncome() > p2.annualIncome() )
      return true;
    return false;
  }
};
*/

/*
bool operator<( const Person & p1, const Person & p2 ) {
  if( p1.age() > p2.age() )
    return true;
  if( p1.age() < p2.age() )
    return false;
  if( p1.annualIncome() > p2.annualIncome() )
    return true;
  return false;
}
*/

int main() {
  int numberPersons = 20;
  std::vector<Person> persons;
  for( int i = 0; i < numberPersons; i++ ) {
    Person p;
    p.age() = floor(((float) rand() / (float) RAND_MAX ) * 100.0f + 0.5f);
    p.annualIncome() = floor(((float) rand() / (float) RAND_MAX ) * 900000.0f + 100000.5f);
    persons.push_back(p);
  }

  for( int i = 0; i < numberPersons; i++ )
    persons[i].print();

  //std::sort(persons.begin(),persons.end(),comparatorFunction);
  //Comp comp;
  //std::sort(persons.begin(),persons.end(),comp);
  std::sort(persons.begin(),persons.end());
  
  for( int i = 0; i < numberPersons; i++ )
    persons[i].print();

  return 0;
}