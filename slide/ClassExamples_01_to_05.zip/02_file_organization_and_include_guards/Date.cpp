#include "Date.hpp"

Date::Date( int year, int month, int day ) {
  m_year = year;
  m_month = month;
  m_day = day;
}