#include "Meeting.hpp"

Meeting::Meeting( Location location, Date date ) : m_location(location), m_date(date) {
}