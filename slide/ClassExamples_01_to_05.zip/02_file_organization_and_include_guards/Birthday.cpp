#include "Birthday.hpp"

Birthday::Birthday( Name name, Date date ) : m_name(name), m_date(date)
{}