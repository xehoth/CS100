#include "Location.hpp"

Location::Location( float longitude, float latitude ) {
  m_longitude = longitude;
  m_latitude = latitude;
}